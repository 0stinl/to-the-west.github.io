Letra da faixa 'Hienas'. Diss sombria e pesada. Beat tipo trap sujo.

_Trecho:_
> Tudo que te falta, sobra em mim...