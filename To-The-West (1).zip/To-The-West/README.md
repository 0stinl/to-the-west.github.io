# 🎵 To The West - Quartel-General

Gravadora independente de Garcia (Ostin Lienn).

Este repositório guarda:
- Letras de músicas
- Conceitos visuais
- Capas de singles e álbuns
- Teasers e roteiros
- Planeamento criativo

> “Da West pro mundo.”